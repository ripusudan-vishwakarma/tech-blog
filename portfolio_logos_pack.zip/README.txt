Original portfolio icon pack. PNG, transparent background, 512x512.
These are custom portfolio icons, not official trademark or certification badge reproductions.
For official AWS/company assets, replace the relevant files with authorized official assets.
